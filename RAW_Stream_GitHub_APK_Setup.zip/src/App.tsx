import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 text-center">
      <div className="max-w-md p-6 bg-slate-800 rounded-2xl border border-slate-700 shadow-xl">
        <h1 className="text-2xl font-bold text-emerald-400 mb-2">আমার অ্যাপ</h1>
        <p className="text-sm text-slate-300 mb-4">
          আপনার অ্যাপটি সফলভাবে অ্যান্ড্রয়েড অ্যাপ হিসেবে চলছে!
        </p>
        <button 
          onClick={() => alert('অভিনন্দন! অ্যাপ সচল আছে।')} 
          className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold transition">
          ক্লিক করুন
        </button>
      </div>
    </div>
  );
}

@echo off
echo ====================================================
echo      Web to APK Builder - Automated Setup
echo ====================================================
echo Step 1: Installing dependencies...
call npm install
call npm install @capacitor/core @capacitor/cli @capacitor/android

echo Step 2: Building Web App bundle...
call npm run build

echo Step 3: Initializing Capacitor Android...
call npx cap add android

echo Step 4: Syncing project...
call npx cap sync

echo Step 5: Opening Android Studio to generate APK...
echo In Android Studio:
echo Click [Build] -^> [Build Bundle(s) / APK(s)] -^> [Build APK(s)]
call npx cap open android
pause
